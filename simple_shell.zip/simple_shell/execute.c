#include "shell.h"

char *builtin_cmd[] = {"cd", "ls", "exit"};
int (*builtin_func[])(char **) = {
    &cd_func
};
int execute(char **cmd)
{

    int i = 0;
    if (cmd == NULL || *cmd == NULL)
        return (-1);

    while (builtin_cmd[i] != NULL)
        {

                if (strcmp(cmd[0], builtin_cmd[i]) == 0)
                {
                        return((*builtin_func[i])(cmd));

                }
                i++;
        }
         
         return (exec_external_cmd(cmd));

}

int exec_external_cmd(char **cmd)
{
        pid_t pid;
	int status;
        find_path();
        pid = fork();
		if (pid == -1)
		{
			perror("fork");
        exit(EXIT_FAILURE);
 		} else if (pid == 0)
		{
			if (execve(cmd[0], cmd, NULL) == -1)
			{
				perror(cmd[0]);
                                 exit(EXIT_FAILURE);
			}
		} else
		{
			if (wait(&status) == -1)
			{
				perror("wait");
                                 exit(EXIT_FAILURE);
			}
                        if (WIFEXITED(status)) {
                   return WEXITSTATUS(status);
                        } else {
                        return -1;
                        }

                                } 
                            return (0);

             
}



/* i will move it to builin_cmd.c file*/
int cd_func(__attribute__((unused)) char **cmd)
{
     if (chdir(cmd[1]) != 0)
    {
        perror(cmd[1]);
        return (-1);
    }

    return (0);
}
