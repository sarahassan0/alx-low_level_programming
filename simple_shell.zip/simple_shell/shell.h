#ifndef _SHELL_H_
#define _SHELL_H_



#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <string.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <linux/limits.h>


char **split_cmd(char *str);
char *_strdup(char *str);
#define BUFF 1024;
void check_interactive(char **argv);
int is_interactive();
int exec_external_cmd(char **cmd);
int execute(char **cmd);


int cd_func(char **cmd);






#endif
