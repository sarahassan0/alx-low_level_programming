#include "shell.h"


/**
 * main - super simple shell that can run commands with their full path,
 * without any argument.
 *
 * Return: 0 on success
 */


int main(int argc, __attribute__((unused)) char *argv[])
{
	/* check if the shell should read from a file*/
	if (argc > 1)
	{
		/*ecec_file(); */
	}

	while (1)
	{

		check_interactive(argv);
	}
	return (0);
}

void check_interactive(char **argv)
{
	if (isatty(STDIN_FILENO))
		is_interactive(argv);

}

int is_interactive()
{
	char *lineptr = NULL;
	size_t len = 0;
	ssize_t read;
	char **cmd = NULL;


	printf("$ ");
	while ((read = getline(&lineptr, &len, stdin)) != -1)
	{
		lineptr[read - 1] == '\n' ? lineptr[read - 1] = '\0' : 0; /*remove the line*/
		cmd = split_cmd(lineptr);
		execute(cmd);

		printf("$ ");

	}
	free(cmd);
	free(lineptr);
	return (0);

}
