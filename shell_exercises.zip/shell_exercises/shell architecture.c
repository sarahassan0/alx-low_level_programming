int main(argc, argv, env)
{

// check if argc >1 if so call func that read from file - 
ecxc_file(argv[1])
// esle call func that check for interactive mode or not - 
check_interacitve()

}

ecxc_script(filename)
{
        //check if file exist
        // if so read it and
        
}

check_interactive()
{
        //use isatty() to check if returnd non-zero int call -
        is_interactive() 
        //else returned 0 the shell reads from pipe and call - 
        is_not_inreractive()
}
is_interactive()
{
        // print $ and starts loop prompt user to enter command
        //reads comands from stdin using
         _gitline()
         //split the command using
         split_cmd() // inside it tokenize the comand using 
         _strtok() //store the splitted command in array of strings and return it
         // this array contains the cmd to be executed and its argumints 
         // so we need to check if this command bulit-in cmd or external cmd using 
         execute() // which check and based of that call ether
         exec_builtin_cmd() or exec_external_cmd()
         //the bulit-in command my program should have are cd & exit & env &setenv and unsetenv & alias 
         cd() & exit() env() & setenv() and unsetenv() ,alias ()
         //afer executing the command the loop continues

         
}
is_not_inreractive()
{
        //read from pipe stream insted of termenal and then do the same cycle in
         is_interactive()

}





//---------------------------------------------- NOTES ----------------
// when using storke im performing in original str so have to be careful when using it with PATH it will chaing it 
//                     so i cannot execute with execv  , i can use strdup and copy it  
// to handel comments in the command i can use strtok using # as delimt to cut the comment from the beginng and then use the rest of command to excute
// use access to check if path accessable
//use perror to print the error of system call 
//You can also use the perror() function to print a descriptive error message based on the current value of errno.
// i can take the exit code and store it in var so wenever "echo $?" for exmple i expand $ and  print this code 
//if you run echo $$ in a shell, you will see the output as the process ID of that shell:
//put env in form of linked list to handel set and unset
// cut comments => expand $ =>


To implement passing a script file as an argument to your own shell and executing the commands in the script, you can follow these steps:

Accept the script file name as a command-line argument when running your own shell. You can use int main(int argc, char *argv[]) to retrieve the command-line arguments. The script file name will be available as argv[1] (assuming it is the second argument).

Open the script file using fopen to get a file pointer. You can check if the file was opened successfully.

Read the commands from the script file line by line using functions like fgets. You can use a loop to iterate through each line of the file until the end is reached.

Parse and execute each command in the same way as if they were entered interactively. You can use strtok or other string manipulation functions to split the command into tokens and then execute the appropriate action.

Close the script file using fclose when you have finished executing all the commands.

Here's a simplified example:
